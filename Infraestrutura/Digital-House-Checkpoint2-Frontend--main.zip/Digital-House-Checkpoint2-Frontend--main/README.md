<h2>2º CHECKPOINT DE FRONT-END</h2>

Primeiro Projeto feito em grupo, espero que gostem do nosso projeto

https://digital-house-checkpoint2-frontend.vercel.app/

:wrench: Requisitos do projeto:
<li>Todo o site deve estar responsivo.</li>
<li>Opcionalmente, o site deve ser feito com Bootstrap.</li>
<li>O site deve ter hover e transições.</li>
<li>O site deve ter rolagem suave (scroll behavior - smooth).</li>



<h5>Feito Com:</h5>

HTML5 CSS3 JAVASCRIPT BOOTSTRAP

:handshake: Integrantes
     <li><a target="_blank" href="https://github.com/Laguiosta">Adrioano A.</a></li>
     <li><a target="_blank" href="https://github.com/JeffersonMendes32">Jefferson Mendes</a></li>
     <li><a target="_blank" href="https://github.com/LuandersonPontes/CTD">Luanderson P.</a></li>
     <li><a target="_blank" href="https://github.com/fehbr800">Matheus Emanoel</a></li>
     <li><a target="_blank" href="https://github.com/naay12">Natali Souza</a></li>
     <li><a target="_blank" href="https://github.com/devrsantos">Renan A.</a></li> 
     <li><a target="_blank" href="https://github.com/vitinop">Victor Luz</a></li> 

https://digital-house-checkpoint2-frontend.vercel.app/
